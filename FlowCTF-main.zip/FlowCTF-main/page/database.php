<?php
    
    $host = "localhost";
    $un = "root";
    $pass = "";
    $db = "flowCTF";

    $conn = new mysqli($host, $un, $pass, $db);

?>